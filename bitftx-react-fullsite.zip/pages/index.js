
import { motion } from 'framer-motion';

export default function Home() {
  return (
    <main className="bg-black text-white min-h-screen p-10">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center">
        <h1 className="text-4xl font-bold mb-4">🚀 BitFtx is Live</h1>
        <p className="text-lg">Predict Crypto. Earn $BFTX. Powered by the future.</p>
      </motion.div>
    </main>
  );
}
