# BitFtx.com – Predict Crypto, Earn $BFTX
This is the full React + Tailwind + Framer Motion site.